sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("handoverfrontend.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);